import { useState, useEffect } from "react";
import "./App.css";
import { ListItem } from "./component/ListItem";
import axios from "axios";
function App() {
  const [loading, setLoading] = useState(true);

  const [list, setList] = useState([]);
  useEffect(() => {
    axios
      .get("https://61e68352ce3a2d00173591f7.mockapi.io/api/list/list")
      .then((d) => {
        setList(d.data);
        setTimeout(() => {
          setLoading(false);
        }, 1500);
      })
      .catch((e) => {
        console.log(e);
      });
  }, []);

  const renderData = (dataList) =>
    dataList.map((node) => <ListItem {...node} />);
  return (
    <div className="App">
      <div className="container">
        {loading && (
          <div className="loader-container">
            <div className="loader">
              <div className="square one"></div>
              <div className="square two"></div>
            </div>
          </div>
        )}
        {renderData(list)}
      </div>
    </div>
  );
}

export default App;
