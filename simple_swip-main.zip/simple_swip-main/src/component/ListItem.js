import { useEffect, useState } from "react";
export const ListItem = (props) => {
  const [startPosition, setStartPosition] = useState(null);
  const [endPosition, setEndPosition] = useState(null);
  const [status, setStatus] = useState(null);

  useEffect(() => {
    if (!startPosition || !endPosition) return;
    const calcDirection = startPosition - endPosition;
    const isSatisfy = Math.abs(calcDirection);
    console.log(isSatisfy);
    const direction = !status ? (calcDirection < 0 ? "right" : "left") : null;
    if (isSatisfy > 80) setStatus(direction);
  }, [endPosition]);

  const handelStartTouch = (e) => {
    const { screenX } = e.changedTouches[0];
    setStartPosition(screenX);
  };
  const handelEndTouch = (e) => {
    const { screenX } = e.changedTouches[0];
    setEndPosition(screenX);
  };

  const handelStartMouse = (e) => {
    const { clientX } = e;
    setStartPosition(clientX);
  };
  const handelEndMouse = (e) => {
    const { clientX } = e;
    setEndPosition(clientX);
  };
  return (
    <div
      onMouseDown={handelStartMouse}
      onTouchStart={handelStartTouch}
      onMouseUp={handelEndMouse}
      onTouchEnd={handelEndTouch}
      className="_item "
      key={props.id}
    >
      <div className={`${status === "right" && "slideIn"} left_side `}>
        <div className="left_option_list">
          <div className="option_size ">
            <img src="/bill.png" />
          </div>
          <div className="option_size">
            <img src="/notification.png" />
          </div>
        </div>
      </div>
      <div className="contentItem">{props.name}</div>

      <div className={`${status == "left" && "slideIn"} right_side `}>
        <div className="right_option_list">
          <div className="option_size color2">DEL</div>
          <div className="option_size color1">Edit</div>
        </div>
      </div>
    </div>
  );
};
